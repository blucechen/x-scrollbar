import typescript from 'rollup-plugin-typescript';

export default {
  input: 'src/index.ts',
  plugins: [
    typescript({lib: ["es5", "es6", "dom"], target: "es6"})
  ],
  output: {
    file: 'dist/mvvm.js',
    format: 'esm',
    banner: '/*\n' +
    ` * mvvm.js  (${new Date().getFullYear()}) \n` +
    ' */'
  },
}