import Watcher from './watcher'
class Observer {
  data: any
  constructor(data) {
    this.data = data
    this.walk(data)
  }
  walk(data) {
    Object.keys(data).forEach(( key )=>{
      this.convert(key, data[key])
    })
  }
  convert(key, val) {
    this.defineReactive(this.data, key, val)
  }
  defineReactive(data, key, val) {
    let dep = new Dep()
    let childObj = observe(val)

    Object.defineProperty(data, key, {
      enumerable: true,
      configurable: false,
      get() {
        if(Dep.target)  
          dep.depend()
        return val
      },
      set(newValue) {
        if(newValue === val) return
        val = newValue
        childObj = observe(newValue)
        dep.notify()
      }
    })

  }
}

let uid = 0
class Dep {
  static target: Watcher|null = null
  id: number
  subs: Watcher[]
  constructor() {
    this.id = uid++
    this.subs = []
  }
  notify() {
    let subs = this.subs.slice()
    subs.forEach(( sub )=>{
      sub.update()
    })
  }
  depend() {
    Dep.target.addDep(this)
  }
  addSub(sub) {
    this.subs.push(sub)
  }
}

function observe(value) {
  if(!value || typeof value !== 'object') return

  return new Observer(value)
}

export {Dep}