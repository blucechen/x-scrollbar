class Compile {
  $vm: any
  $el: HTMLElement
  $fragment: DocumentFragment

  constructor(el: HTMLElement|string, vm: any) {
    this.$vm = vm
    this.$el = Compile.isElementNode(el)? <HTMLElement>el: document.querySelector(<string>el)
    
    if(this.$el) {
      this.$fragment = Compile.node2Fragment(this.$el)
      this.init()
      this.$el.appendChild(this.$fragment)
    }
  }

  init() {
    this.compileElement(this.$fragment)
  }

  compileElement(el: Node) {
    let childNodes:NodeListOf<ChildNode> = el.childNodes
    let reg = /\{\{(.*)\}\}/
    Array.from(childNodes).forEach(( ele: ChildNode )=>{
      let text = ele.textContent
      if(Compile.isElementNode(ele)) {
        this.compile(<HTMLElement>ele)
      } else if(Compile.isTextNode(ele) && reg.test(text)) {
        this.compileText(ele, RegExp.$1.trim())
      }
      if(ele.childNodes && ele.childNodes.length) {
        this.compileElement(ele)
      }
    })
  } 

  compileText(ele: Node, exp: string) {
    DirectiveUtils.text(ele, this.$vm, exp)
  }

  compile(ele: HTMLElement) {
    let nodeAttrs = ele.attributes
    Array.from(nodeAttrs).forEach(( attr: Attr )=>{
      let attrName = attr.name
      if(!Compile.isDirective(attrName)) return

      var exp = attr.value
      var dir = attrName.slice(2)
      if(Compile.isEventDirective(dir)) {
        DirectiveUtils.eventHandler(ele, this.$vm, exp, dir)
      } else {
        DirectiveUtils[dir] && DirectiveUtils[dir](ele, this.$vm, exp)
      }
    })
  }
  static isEventDirective(dir: string):boolean {

    return false
  }
  static isDirective(attr: string) {
    return attr.indexOf('v-') === 0
  }
  static node2Fragment(el: HTMLElement): DocumentFragment {
    let fragment = document.createDocumentFragment(), child
    while(child = el.firstChild) {
      fragment.appendChild(child)
    }
    return fragment
  }
  static isElementNode(el: Node|string): boolean {
    return el instanceof Node && el.nodeType === 1
  }
  static isTextNode(el: Node|string):boolean {
    return el instanceof Node && el.nodeType === 3
  }
}


class DirectiveUtils {
  static eventHandler(ele: HTMLElement, vm: any, exp: string, dir: string) {
    
  }
  static text(node: Node, vm: any, exp: string) {
    DirectiveUtils.bind(node, vm, exp, 'text')
  }
  static bind(node: Node, vm: any, exp: string, arg3: string) {
    throw new Error("Method not implemented.")
  }
  static html() {

  }
  static model() {

  }
  static class() {
    
  }
  static _getVMVal() {

  }
  static _setVMVal() {

  }
  
  // static eventHandler()
}
