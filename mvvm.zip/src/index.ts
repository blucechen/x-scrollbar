function MVVM() {
  
}
new MVVM()




