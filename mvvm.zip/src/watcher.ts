import { Dep } from "./observer"
class Watcher {
  
  cb: any
  vm: any
  expOrFn: any
  depIds: {}
  getter: any
  value: any
  constructor(vm, expOrFn, cb) {
    this.cb = cb
    this.vm = vm
    this.expOrFn = expOrFn
    this.depIds = {}

    if(typeof expOrFn === 'function')
      this.getter = expOrFn
    else 
      this.getter = this.parserGetter(expOrFn.trim())

    this.value = this.get()
  }
  parserGetter(exp): any {
    if(/[^\w.$]/.test(exp)) return // /[^\w.$]/测试非法字符，变量不支持的

    let exps = exp.split('.')
    return function (obj) {
      exps.forEach(exp => {
        obj = obj[exp]
      })
      return obj
    }
  }
  update() {
    var value = this.get()
    var oldValue = this.value
    if(value !== oldValue) {
      this.value = value
      this.cb.call(this.vm, value, oldValue)
    }
  }
  get(): any {
    Dep.target = this
    var value = this.getter.call(this.vm, this.vm)
    Dep.target = null
    return value
  }
  addDep(dep: Dep) {
    if(!this.depIds.hasOwnProperty(dep.id)) return
    this.depIds[dep.id] = dep
  }
}
export default Watcher


